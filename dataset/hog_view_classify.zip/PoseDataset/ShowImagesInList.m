function ShowImagesInList(listfile)
fp = fopen(listfile, 'r');

while 1
    filename = fgetl(fp);
    if ~ischar(filename) break; end
    imshow(filename);
    fprintf('%s\n', filename);
    pause;
end
end
clear
npose = 4;

%% make sure to compile
cd 3rdParty/libsvm-3.17/matlab/
make
cd ../../..

%% 
addpath(genpath('./3rdParty'))

dataroot = 'PoseDataset';

if(npose == 4)
    % 4 pose
    for p = 1:4
        list{p} = importdata(['PoseDataset/annotations/pose4/pose' num2str(p, '%03d') '_4.lst']);
    end
else
    % 8 pose
    for p = 1:8
        list{p} = importdata(['PoseDataset/annotations/pose' num2str(p, '%03d') 'ex.lst']);
    end
end

%% extract HOG descriptors
cropwindow = [21, 140, 19, 78];

hogset = cell(length(list), 1);
for i = 1:length(list)
    disp(['processing pose ' num2str(i)]);
    
    hogset{i} = zeros(length(list{i}), 2688);
    
    for j = 1:length(list{i})
        fname = fullfile(dataroot, list{i}{j});
        im = imread(fname);
        
        imcropped = im(cropwindow(1):cropwindow(2), cropwindow(3):cropwindow(4), :);
        scaled = imresize(imcropped, [128, 64]);
        hog = features(double(scaled), 8);
        
%         % visualize       
%         subplot(121);
%         imshow(imcropped);
%         subplot(122);
%         visualizeHOG(hog);
%         pause
        
        hogset{i}(j, :) = hog(:)';
    end
end
save(['hogset' num2str(npose)], 'hogset');

%% train pose classifier
labels = [];
feats = [];

for i = 1:length(hogset)
    labels = [labels; i * ones(size(hogset{i}, 1), 1)];
    feats = [feats; hogset{i}];
end
model = svmtrain(labels, feats, ' -c 1 -t 0');

%% test pose 
%% collect features
clear list feats labels

if(npose == 4)
    % 4 pose
    count = 1;
    for p = [1 3 5 7]
        list{count} = importdata(['PoseDataset/annotations/pose' num2str(p, '%03d') '_test.lst']);
        count = count + 1;
    end
else
    % 8 pose
    for p = 1:8
        list{p} = importdata(['PoseDataset/annotations/pose' num2str(p, '%03d') '_test.lst']);
    end
end

labels = [];
feats = [];

for i = 1:length(list)
    disp(['processing pose ' num2str(i)]);
    
    hogset{i} = zeros(length(list{i}), 2688);
    
    for j = 1:length(list{i})
        fname = fullfile(dataroot, list{i}{j});
        im = imread(fname);
        
        scaled = imresize(im, [128, 64]);
        hog = features(double(scaled), 8);
        
        labels = [labels; i];
        feats = [feats; hog(:)'];
    end
end
%% test classifier
[pose_est] = svmpredict(labels, feats, model);

%% draw ctable
ctable = zeros(npose, npose);
for i = 1:length(pose_est)
    ctable(labels(i), pose_est(i)) = ctable(labels(i), pose_est(i)) + 1;
end

drawCTable(ctable, {'f' 'fr' 'r' 'br' 'b' 'bl' 'l' 'fl'});